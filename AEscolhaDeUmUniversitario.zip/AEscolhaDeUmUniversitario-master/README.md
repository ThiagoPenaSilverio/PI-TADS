One Sheet Paper

Nome do jogo: A escolha de um universit�rio

Sum�rio:
Voc� entra na universidade e tem que lidar com as decis�es da vida adulta.

Gameplay:
H� tr�s diferentes atributos em jogo - Dinheiro, intelig�ncia e fama - que s�o influenciados pelas decis�es do jogador no decorrer do tempo. O jogo � constitu�do de m�ltiplos objetivos, os principais sendo: chegar a formatura, ou seja, ao final; E n�o deixar que nenhum dos atributos chegue a zero ou ultrapasse 100, o que ocasionaria em um Game Over.
Com cada carta simbolizando a passagem de um m�s, a dura��o m�dia do jogo ser� de 48 cartas, a dura��o de uma gradua��o.

Controles e Mec�nicas:
Usando o mouse/teclado, o jogador ir� clicar em um dos lados da tela/utilizar as setas (esquerda ou direita) para tomar uma decis�o sobre a situa��o que lhe foi dada. As escolhas do jogador podem aumentar ou diminuir pontos dos atributos e geram consequ�ncias futuras, que podem obrig�-lo a tomar decis�es que ele n�o gostaria ou apenas chegar num final inevit�vel.
Caso o player acumule 3 depend�ncias, ele perde o jogo.

Fluxo do jogo:
Jogador cria seu personagem (nome, sexo)
Jogador seleciona qual faculdade gostaria de fazer
A primeira carta, com uma escolha n�o t�o relevante, � apresentada (� ensinado como fazer as escolhas)
O jogador progride fazendo suas escolhas para que seus atributos n�o cheguem em zero.
Durante o decorrer do jogo, haver�o grandes acontecimentos que ter�o mais influ�ncia sobre os atributos
Ao fim de cada semestre, o jogador receber� um resumo de seu desempenho.

Gr�ficos e �udio:
Usando o estilo 8 bits, presentes em videogames cl�ssicos, com um visual minimalista, mas ainda assim bonito e compreens�vel. Tanto a parte gr�fica e visual quanto a parte sonora puxar�o para a simplicidade e nostalgia dos videogames antigos.
